# Include the current weather into your game mechanics.

URL = "https://www.metaweather.com/api/"
