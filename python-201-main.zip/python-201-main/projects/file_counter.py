# Add the code for the file counter script that you wrote in the course.
