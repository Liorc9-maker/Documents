# Add an API call to your CLI game that assigns a name to your player.
