# Create a lambda expression that takes no input
# and prints "hello world" to the console. What does it return?
