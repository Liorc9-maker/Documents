# soup.py
def make_soup(ingredient):
    soup = f"{ingredient} soup"
    print(f"You've made {soup}")
    return soup
