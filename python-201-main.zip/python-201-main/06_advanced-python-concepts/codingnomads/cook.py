# cook.py
soup = "pumpkin soup"

print(f"{soup} is soooo good!")
