# Write a lambda expression that takes in three numbers
# and returns the sum of the numbers.
