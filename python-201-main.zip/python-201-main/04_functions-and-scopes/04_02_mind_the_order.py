# Something is wrong with the way you're calling the function below.
# Can you fix it and survive?

def skydive(step_1, step_2):
    print("For your own safety, please follow the instructions carefully:")
    print(f"1. {step_1}")
    print(f"2. {step_2}")

skydive("JUMP!", "Take your parachute.")
