# Fix the code below to make it possible to print out
# the uppercase copy of the name.
# - use `return` to create an output for the function
# - assign the output to a variable
# - print that variable

def shout(name):
    loud_name = name.upper()

shout("wilma")
print(loud_name)
