# Use the `csv` module to read in and count the different file types.
