# Write the file counts to a `.csv` file.
